'use client'

import React, { useState, useEffect, useRef } from 'react'
import { useForm, useFieldArray } from 'react-hook-form'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Plus,
  Trash2,
  CalendarIcon,
  Save,
  FileText,
  X,
  Loader2,
  Sparkles,
  Wand2,
  Check,
  RotateCcw,
  Zap,
  Palette,
} from 'lucide-react'
import { format, addDays } from 'date-fns'

import { cn } from '@/lib/utils'
import { numberToWords } from '@/lib/numberToWords'
import { CURRENCIES, getCurrencySymbol, formatCurrencyAmount } from '@/lib/currency'
import { useAppStore } from '@/stores/appStore'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import InvoiceTemplates, { getStoredTemplate, setStoredTemplate, type TemplateName } from '@/components/invoice/InvoiceTemplates'

const TAX_OPTIONS = [
  { label: '0%', value: 0 },
  { label: '5%', value: 5 },
  { label: '12%', value: 12 },
  { label: '18%', value: 18 },
  { label: '28%', value: 28 },
  { label: 'Custom', value: -1 },
]

interface InvoiceItemForm {
  description: string
  quantity: number
  rate: number
  taxPercent: number
  amount: number
}

interface InvoiceFormValues {
  invoiceNumber: string
  invoiceDate: string
  dueDate: string
  billToName: string
  billToPhone: string
  billToEmail: string
  billToAddress: string
  items: InvoiceItemForm[]
  receivedAmount: number
  previousBalance: number
  termsText: string
  currency: string
}

interface Customer {
  id: string
  name: string
  phone: string
  email: string
  address: string
}

const DRAFT_KEY = 'invoice-draft'

export default function InvoiceForm() {
  const {
    user,
    setCurrentView,
    setPreviewInvoiceId,
    editInvoiceId,
    setEditInvoiceId,
  } = useAppStore()

  const [customers, setCustomers] = useState<Customer[]>([])
  const [showCustomerSuggestions, setShowCustomerSuggestions] = useState(false)
  const [customTaxIndex, setCustomTaxIndex] = useState<number | null>(null)
  const [customTaxValues, setCustomTaxValues] = useState<Record<number, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isLoadingInvoice, setIsLoadingInvoice] = useState(false)
  const [showRecurringDialog, setShowRecurringDialog] = useState(false)
  const [recurringTemplateName, setRecurringTemplateName] = useState('')
  const [recurringFrequency, setRecurringFrequency] = useState('monthly')
  const autoSaveTimerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // Template state
  const [selectedTemplate, setSelectedTemplate] = useState<TemplateName>(getStoredTemplate)
  const [showTemplates, setShowTemplates] = useState(false)

  // AI Assistant state
  const [aiPrompt, setAiPrompt] = useState('')
  const [aiLoading, setAiLoading] = useState(false)
  const [aiSuggestions, setAiSuggestions] = useState<{
    items: { description: string; quantity: number; rate: number; taxPercent: number }[]
    billToName: string
    notes: string
  } | null>(null)
  const [aiError, setAiError] = useState('')
  const [showAiPreview, setShowAiPreview] = useState(false)

  const today = format(new Date(), 'yyyy-MM-dd')
  const defaultDueDate = format(addDays(new Date(), 7), 'yyyy-MM-dd')

  const defaultItems: InvoiceItemForm[] = [
    { description: '', quantity: 1, rate: 0, taxPercent: 0, amount: 0 },
  ]

  const form = useForm<InvoiceFormValues>({
    defaultValues: {
      invoiceNumber: '',
      invoiceDate: today,
      dueDate: defaultDueDate,
      billToName: '',
      billToPhone: '',
      billToEmail: '',
      billToAddress: '',
      items: defaultItems,
      receivedAmount: 0,
      previousBalance: 0,
      termsText: '',
      currency: 'INR',
    },
  })

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: 'items',
  })

  const watchedItems = form.watch('items')
  const watchedReceivedAmount = form.watch('receivedAmount')
  const watchedPreviousBalance = form.watch('previousBalance')
  const watchedCurrency = form.watch('currency') || 'INR'
  const currencySymbol = getCurrencySymbol(watchedCurrency)

  // Calculate totals
  const subtotal = watchedItems.reduce((sum, item) => {
    const base = item.quantity * item.rate
    return sum + base
  }, 0)

  const taxTotal = watchedItems.reduce((sum, item) => {
    const base = item.quantity * item.rate
    const taxAmount = (base * item.taxPercent) / 100
    return sum + taxAmount
  }, 0)

  const grandTotal = subtotal + taxTotal
  const currentBalance = grandTotal - (watchedReceivedAmount || 0) + (watchedPreviousBalance || 0)
  const amountInWords = numberToWords(grandTotal, watchedCurrency)

  // Auto-update amounts for each item
  useEffect(() => {
    watchedItems.forEach((item, index) => {
      const base = item.quantity * item.rate
      const taxAmount = (base * item.taxPercent) / 100
      const amount = base + taxAmount
      const roundedAmount = Math.round(amount * 100) / 100
      if (item.amount !== roundedAmount) {
        form.setValue(`items.${index}.amount`, roundedAmount, { shouldValidate: false, shouldDirty: false })
      }
    })
  }, [watchedItems.map(i => `${i.quantity}-${i.rate}-${i.taxPercent}`).join(',')])

  // Fetch customers for autocomplete
  useEffect(() => {
    if (user?.id) {
      fetch(`/api/customers?userId=${user.id}`)
        .then(res => res.json())
        .then(data => {
          if (data.customers) setCustomers(data.customers)
        })
        .catch(() => {})
    }
  }, [user?.id])

  // Load invoice for editing
  useEffect(() => {
    if (editInvoiceId && user?.id) {
      setIsLoadingInvoice(true)
      fetch(`/api/invoices?userId=${user.id}`)
        .then(res => res.json())
        .then(data => {
          const invoice = data.invoices?.find((inv: { id: string }) => inv.id === editInvoiceId)
          if (invoice) {
            form.reset({
              invoiceNumber: invoice.invoiceNumber,
              invoiceDate: invoice.invoiceDate,
              dueDate: invoice.dueDate,
              billToName: invoice.billToName || '',
              billToPhone: invoice.billToPhone || '',
              billToEmail: invoice.billToEmail || '',
              billToAddress: invoice.billToAddress || '',
              items: invoice.items?.length > 0
                ? invoice.items.map((item: { description: string; quantity: number; rate: number; taxPercent: number; amount: number }) => ({
                    description: item.description || '',
                    quantity: item.quantity || 1,
                    rate: item.rate || 0,
                    taxPercent: item.taxPercent || 0,
                    amount: item.amount || 0,
                  }))
                : defaultItems,
              receivedAmount: invoice.receivedAmount || 0,
              previousBalance: invoice.previousBalance || 0,
              termsText: invoice.termsText || '',
              currency: invoice.currency || 'INR',
            })
          }
        })
        .catch(() => toast.error('Failed to load invoice'))
        .finally(() => setIsLoadingInvoice(false))
    }
  }, [editInvoiceId, user?.id])

  // Auto-generate invoice number
  useEffect(() => {
    if (!editInvoiceId && user?.id && !form.getValues('invoiceNumber')) {
      const year = new Date().getFullYear()
      fetch(`/api/invoices?userId=${user.id}`)
        .then(res => res.json())
        .then(data => {
          const count = data.invoices?.length || 0
          const nextNum = `INV-${year}-${String(count + 1).padStart(3, '0')}`
          form.setValue('invoiceNumber', nextNum)
        })
        .catch(() => {
          form.setValue('invoiceNumber', `INV-${year}-001`)
        })
    }
  }, [user?.id, editInvoiceId])

  // Auto-save draft every 30 seconds
  useEffect(() => {
    autoSaveTimerRef.current = setInterval(() => {
      const values = form.getValues()
      if (values.items.some(i => i.description || i.rate > 0) || values.billToName) {
        localStorage.setItem(DRAFT_KEY, JSON.stringify(values))
      }
    }, 30000)

    return () => {
      if (autoSaveTimerRef.current) clearInterval(autoSaveTimerRef.current)
    }
  }, [])

  // Load draft on mount (if not editing)
  useEffect(() => {
    if (!editInvoiceId) {
      const saved = localStorage.getItem(DRAFT_KEY)
      if (saved) {
        try {
          const draft = JSON.parse(saved)
          form.reset(draft)
        } catch {
          // ignore
        }
      }
    }
  }, [])

  const selectCustomer = (customer: Customer) => {
    form.setValue('billToName', customer.name)
    form.setValue('billToPhone', customer.phone)
    form.setValue('billToEmail', customer.email)
    form.setValue('billToAddress', customer.address)
    setShowCustomerSuggestions(false)
  }

  const handleTaxChange = (index: number, value: string) => {
    const numValue = parseFloat(value)
    if (numValue === -1) {
      setCustomTaxIndex(index)
      setCustomTaxValues(prev => ({ ...prev, [index]: '' }))
    } else {
      form.setValue(`items.${index}.taxPercent`, numValue)
      if (customTaxIndex === index) setCustomTaxIndex(null)
    }
  }

  const handleCustomTaxInput = (index: number, value: string) => {
    setCustomTaxValues(prev => ({ ...prev, [index]: value }))
    const numVal = parseFloat(value)
    if (!isNaN(numVal) && numVal >= 0) {
      form.setValue(`items.${index}.taxPercent`, numVal)
    }
  }

  const addItem = () => {
    append({ description: '', quantity: 1, rate: 0, taxPercent: 0, amount: 0 })
  }

  const onSubmit = async (data: InvoiceFormValues, status: string = 'sent') => {
    if (!user?.id) {
      toast.error('Please login first')
      return
    }

    setIsSubmitting(true)
    try {
      const payload = {
        ...data,
        userId: user.id,
        subtotal,
        taxTotal,
        grandTotal,
        currentBalance,
        amountInWords,
        status,
        items: data.items.map(item => ({
          description: item.description,
          quantity: item.quantity,
          rate: item.rate,
          taxPercent: item.taxPercent,
          amount: item.amount,
        })),
      }

      let response: Response
      if (editInvoiceId) {
        response = await fetch('/api/invoices/update', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: editInvoiceId, ...payload }),
        })
      } else {
        response = await fetch('/api/invoices/create', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        })
      }

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || 'Failed to save invoice')
      }

      localStorage.removeItem(DRAFT_KEY)

      if (status === 'draft') {
        toast.success('Draft saved successfully')
        setCurrentView('invoices')
      } else {
        toast.success('Invoice generated successfully')
        setPreviewInvoiceId(result.invoice.id)
        setEditInvoiceId(null)
        setCurrentView('preview-invoice')
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to save invoice')
    } finally {
      setIsSubmitting(false)
    }
  }

  // AI Suggest handler
  const handleAiSuggest = async () => {
    if (!aiPrompt.trim()) return

    setAiLoading(true)
    setAiError('')
    setAiSuggestions(null)
    setShowAiPreview(false)

    try {
      const response = await fetch('/api/ai/suggest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: aiPrompt.trim(),
          userId: user?.id,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Failed to get AI suggestions')
      }

      setAiSuggestions(data)
      setShowAiPreview(true)
    } catch (error) {
      setAiError(error instanceof Error ? error.message : 'Something went wrong. Please try again.')
    } finally {
      setAiLoading(false)
    }
  }

  // Apply AI suggestions to the form
  const applyAiSuggestions = () => {
    if (!aiSuggestions) return

    // Apply billToName if detected
    if (aiSuggestions.billToName) {
      form.setValue('billToName', aiSuggestions.billToName)
    }

    // Replace items with AI-suggested items
    const currentItems = form.getValues('items')
    const aiItems = aiSuggestions.items.map((item) => ({
      description: item.description,
      quantity: item.quantity,
      rate: item.rate,
      taxPercent: item.taxPercent,
      amount: Math.round((item.quantity * item.rate * (1 + item.taxPercent / 100)) * 100) / 100,
    }))

    // Remove all existing items and add AI items
    // First, remove all items from the end
    for (let i = currentItems.length - 1; i >= 0; i--) {
      remove(i)
    }

    // Then add all AI items
    for (const item of aiItems) {
      append(item)
    }

    // Close the preview and reset
    setShowAiPreview(false)
    setAiSuggestions(null)
    setAiPrompt('')

    toast.success('AI suggestions applied to your invoice!')
  }

  if (isLoadingInvoice) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
      </div>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="max-w-5xl mx-auto p-4 md:p-6 space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground">
            {editInvoiceId ? 'Edit Invoice' : 'Create Invoice'}
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            {editInvoiceId ? 'Update invoice details' : 'Fill in the details to generate a new invoice'}
          </p>
        </div>
        <Badge variant="secondary" className="text-xs">
          Auto-saved
        </Badge>
      </div>

      <form className="space-y-6 animate-fade-in">
        {/* Gradient section divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-emerald-300 dark:via-emerald-700 to-transparent" />

        {/* SECTION 1 - Invoice Details */}
        <Card className="border-border/50 shadow-sm card-shine">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <FileText className="h-5 w-5 text-emerald-600" />
              Invoice Details
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="invoiceNumber">Invoice Number</Label>
                <Input
                  id="invoiceNumber"
                  {...form.register('invoiceNumber')}
                  placeholder="INV-2026-001"
                  className="font-mono"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="invoiceTemplate">Template</Label>
                <div className="flex gap-2">
                  <Select
                    value={selectedTemplate}
                    onValueChange={(val) => {
                      setSelectedTemplate(val as TemplateName)
                      setStoredTemplate(val as TemplateName)
                    }}
                  >
                    <SelectTrigger id="invoiceTemplate" className="flex-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="classic">
                        <span className="flex items-center gap-2">
                          <span className="h-2 w-2 rounded-full bg-emerald-500" />
                          Classic
                        </span>
                      </SelectItem>
                      <SelectItem value="modern">
                        <span className="flex items-center gap-2">
                          <span className="h-2 w-2 rounded-full bg-teal-500" />
                          Modern
                        </span>
                      </SelectItem>
                      <SelectItem value="creative">
                        <span className="flex items-center gap-2">
                          <span className="h-2 w-2 rounded-full bg-amber-500" />
                          Creative
                        </span>
                      </SelectItem>
                      <SelectItem value="professional">
                        <span className="flex items-center gap-2">
                          <span className="h-2 w-2 rounded-full bg-gray-500" />
                          Professional
                        </span>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    className="flex-shrink-0 border-emerald-300 text-emerald-600 hover:bg-emerald-50 dark:border-emerald-700 dark:text-emerald-400 dark:hover:bg-emerald-950"
                    onClick={() => setShowTemplates(true)}
                  >
                    <Palette className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="currency">Currency</Label>
                <Select
                  value={watchedCurrency}
                  onValueChange={(val) => form.setValue('currency', val)}
                >
                  <SelectTrigger id="currency">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CURRENCIES.map((c) => (
                      <SelectItem key={c.code} value={c.code}>
                        {c.symbol} {c.code} — {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Invoice Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'w-full justify-start text-left font-normal',
                        !form.watch('invoiceDate') && 'text-muted-foreground'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {form.watch('invoiceDate')
                        ? format(new Date(form.watch('invoiceDate')), 'dd MMM yyyy')
                        : 'Pick a date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={form.watch('invoiceDate') ? new Date(form.watch('invoiceDate')) : new Date()}
                      onSelect={(date) => {
                        if (date) form.setValue('invoiceDate', format(date, 'yyyy-MM-dd'))
                      }}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label>Due Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'w-full justify-start text-left font-normal',
                        !form.watch('dueDate') && 'text-muted-foreground'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {form.watch('dueDate')
                        ? format(new Date(form.watch('dueDate')), 'dd MMM yyyy')
                        : 'Pick a date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={form.watch('dueDate') ? new Date(form.watch('dueDate')) : addDays(new Date(), 7)}
                      onSelect={(date) => {
                        if (date) form.setValue('dueDate', format(date, 'yyyy-MM-dd'))
                      }}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Gradient section divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-teal-300 dark:via-teal-700 to-transparent" />

        {/* AI ASSISTANT SECTION */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        >
          <div className="relative">
            {/* Gradient border effect - pulsing glow */}
            <div className="absolute -inset-[1px] rounded-xl bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500 opacity-60 blur-[1px] animate-glow-pulse group-hover:opacity-100 transition-opacity duration-500" />
            <Card className="relative border-0 shadow-lg overflow-hidden">
              {/* Subtle animated background shimmer */}
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-50/50 via-transparent to-teal-50/50 dark:from-emerald-950/20 dark:via-transparent dark:to-teal-950/20" />
              <div className="relative">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <div className="flex items-center justify-center h-7 w-7 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-500 text-white">
                      <Sparkles className="h-4 w-4" />
                    </div>
                    AI Invoice Assistant
                    <Badge variant="secondary" className="ml-1 text-[10px] bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300 border-0">
                      <Zap className="h-2.5 w-2.5 mr-0.5" />
                      Powered by AI
                    </Badge>
                  </CardTitle>
                  <p className="text-xs text-muted-foreground mt-1">
                    Describe what you want to invoice in plain language and let AI generate the items for you.
                  </p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="ai-prompt" className="text-sm font-medium">
                      What do you want to invoice?
                    </Label>
                    <div className="relative">
                      <Textarea
                        id="ai-prompt"
                        value={aiPrompt}
                        onChange={(e) => { setAiPrompt(e.target.value); setAiError('') }}
                        placeholder="e.g., &quot;Invoice for Acme Corp — 3 months of web development, UI design, and server maintenance&quot; or &quot;Logo design and branding package for Priya Sharma&quot;"
                        rows={3}
                        className="resize-none pr-10 border-emerald-200 dark:border-emerald-800 focus-visible:ring-emerald-500"
                        disabled={aiLoading}
                      />
                      <div className="absolute right-2 top-2">
                        <Sparkles className="h-4 w-4 text-emerald-400" />
                      </div>
                    </div>
                  </div>

                  {/* Generate Button */}
                  <div className="flex items-center gap-3">
                    <Button
                      type="button"
                      onClick={handleAiSuggest}
                      disabled={aiLoading || !aiPrompt.trim()}
                      className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-md hover:shadow-lg transition-all duration-200"
                    >
                      {aiLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Generating
                          <span className="inline-flex ml-1 gap-0.5">
                            <motion.span
                              animate={{ opacity: [0, 1, 0] }}
                              transition={{ duration: 1, repeat: Infinity, delay: 0 }}
                            >.</motion.span>
                            <motion.span
                              animate={{ opacity: [0, 1, 0] }}
                              transition={{ duration: 1, repeat: Infinity, delay: 0.2 }}
                            >.</motion.span>
                            <motion.span
                              animate={{ opacity: [0, 1, 0] }}
                              transition={{ duration: 1, repeat: Infinity, delay: 0.4 }}
                            >.</motion.span>
                          </span>
                        </>
                      ) : (
                        <>
                          <Wand2 className="mr-2 h-4 w-4" />
                          Generate with AI
                        </>
                      )}
                    </Button>
                    {aiSuggestions && !showAiPreview && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setShowAiPreview(true)}
                        className="text-emerald-600 border-emerald-300 hover:bg-emerald-50 dark:border-emerald-700 dark:hover:bg-emerald-950"
                      >
                        <RotateCcw className="mr-1.5 h-3.5 w-3.5" />
                        Show Last Suggestions
                      </Button>
                    )}
                  </div>

                  {/* Error State */}
                  {aiError && (
                    <motion.div
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="rounded-lg bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 p-3"
                    >
                      <p className="text-sm text-red-700 dark:text-red-300">{aiError}</p>
                    </motion.div>
                  )}

                  {/* AI Suggestions Preview */}
                  <AnimatePresence>
                    {showAiPreview && aiSuggestions && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden"
                      >
                        <div className="rounded-xl border border-emerald-200 dark:border-emerald-800 bg-gradient-to-br from-emerald-50/80 to-teal-50/80 dark:from-emerald-950/30 dark:to-teal-950/30 p-4 space-y-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className="h-6 w-6 rounded-full bg-emerald-500 text-white flex items-center justify-center">
                                <Sparkles className="h-3 w-3" />
                              </div>
                              <span className="text-sm font-semibold text-emerald-800 dark:text-emerald-200">
                                AI Suggestions
                              </span>
                              <Badge className="text-[10px] bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300 border-0">
                                {aiSuggestions.items.length} item{aiSuggestions.items.length > 1 ? 's' : ''}
                              </Badge>
                            </div>
                            <button
                              type="button"
                              onClick={() => { setShowAiPreview(false) }}
                              className="text-muted-foreground hover:text-foreground transition-colors"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </div>

                          {aiSuggestions.billToName && (
                            <div className="flex items-center gap-2 text-sm">
                              <span className="text-muted-foreground">Customer:</span>
                              <span className="font-medium text-emerald-700 dark:text-emerald-300">
                                {aiSuggestions.billToName}
                              </span>
                            </div>
                          )}

                          {/* Items Preview */}
                          <div className="space-y-2">
                            {aiSuggestions.items.map((item, idx) => (
                              <motion.div
                                key={idx}
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: idx * 0.08 }}
                                className="flex items-center justify-between bg-white/70 dark:bg-background/70 rounded-lg p-3 border border-emerald-100 dark:border-emerald-900"
                              >
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-2">
                                    <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
                                      #{idx + 1}
                                    </span>
                                    <span className="text-sm font-medium truncate">
                                      {item.description}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                                    <span>Qty: {item.quantity}</span>
                                    <span>Rate: {currencySymbol}{item.rate.toLocaleString('en-IN')}</span>
                                    <span className="text-emerald-600 dark:text-emerald-400">
                                      GST: {item.taxPercent}%
                                    </span>
                                  </div>
                                </div>
                                <div className="text-right ml-3">
                                  <span className="text-sm font-semibold text-emerald-700 dark:text-emerald-300">
                                    {currencySymbol}{((item.quantity * item.rate) * (1 + item.taxPercent / 100)).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                                  </span>
                                </div>
                              </motion.div>
                            ))}
                          </div>

                          {/* Total Preview */}
                          <div className="flex items-center justify-between pt-2 border-t border-emerald-200 dark:border-emerald-800">
                            <span className="text-sm font-medium">Estimated Total</span>
                            <span className="text-lg font-bold text-emerald-700 dark:text-emerald-300">
                              {currencySymbol}{aiSuggestions.items.reduce((sum, item) => {
                                const base = item.quantity * item.rate
                                const taxAmount = (base * item.taxPercent) / 100
                                return sum + base + taxAmount
                              }, 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                            </span>
                          </div>

                          {aiSuggestions.notes && (
                            <p className="text-xs text-muted-foreground italic">
                              {aiSuggestions.notes}
                            </p>
                          )}

                          {/* Action Buttons */}
                          <div className="flex items-center gap-3 pt-1">
                            <Button
                              type="button"
                              onClick={applyAiSuggestions}
                              className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white"
                            >
                              <Check className="mr-2 h-4 w-4" />
                              Apply Suggestions
                            </Button>
                            <Button
                              type="button"
                              variant="outline"
                              onClick={() => {
                                setAiSuggestions(null)
                                setShowAiPreview(false)
                                setAiPrompt('')
                              }}
                              className="flex-1 border-emerald-300 text-emerald-600 hover:bg-emerald-50 dark:border-emerald-700 dark:text-emerald-400 dark:hover:bg-emerald-950"
                            >
                              <X className="mr-2 h-4 w-4" />
                              Discard
                            </Button>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Quick prompt suggestions */}
                  {!aiSuggestions && !aiLoading && (
                    <div className="flex flex-wrap gap-2">
                      <span className="text-xs text-muted-foreground self-center">Try:</span>
                      {[
                        'Web design and development for a startup',
                        'Monthly accounting services',
                        'Logo design and branding package for TechCorp',
                        'IT consulting — 40 hours',
                      ].map((suggestion) => (
                        <button
                          key={suggestion}
                          type="button"
                          onClick={() => setAiPrompt(suggestion)}
                          className="text-xs px-2.5 py-1 rounded-full border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 bg-emerald-50/50 dark:bg-emerald-950/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition-colors"
                        >
                          {suggestion}
                        </button>
                      ))}
                    </div>
                  )}
                </CardContent>
              </div>
            </Card>
          </div>
        </motion.div>

        {/* Gradient section divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-cyan-300 dark:via-cyan-700 to-transparent" />

        {/* SECTION 2 - Bill To */}
        <Card className="border-border/50 shadow-sm card-shine">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <svg className="h-5 w-5 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                <circle cx="12" cy="7" r="4" />
              </svg>
              Bill To
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2 relative">
                <Label htmlFor="billToName">Customer Name</Label>
                <Input
                  id="billToName"
                  {...form.register('billToName')}
                  placeholder="Enter customer name"
                  onFocus={() => setShowCustomerSuggestions(true)}
                  onBlur={() => setTimeout(() => setShowCustomerSuggestions(false), 200)}
                />
                <AnimatePresence>
                  {showCustomerSuggestions && customers.length > 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -5 }}
                      className="absolute z-50 top-full left-0 right-0 mt-1"
                    >
                      <div className="bg-popover border border-border rounded-md shadow-lg max-h-48 overflow-y-auto">
                        {customers
                          .filter(c =>
                            c.name.toLowerCase().includes((form.watch('billToName') || '').toLowerCase())
                          )
                          .map(customer => (
                            <button
                              key={customer.id}
                              type="button"
                              className="w-full text-left px-3 py-2 hover:bg-accent text-sm transition-colors"
                              onMouseDown={() => selectCustomer(customer)}
                            >
                              <div className="font-medium">{customer.name}</div>
                              {customer.email && (
                                <div className="text-xs text-muted-foreground">{customer.email}</div>
                              )}
                            </button>
                          ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="space-y-2">
                <Label htmlFor="billToPhone">Phone Number</Label>
                <Input
                  id="billToPhone"
                  {...form.register('billToPhone')}
                  placeholder="Enter phone number"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="billToEmail">Email</Label>
                <Input
                  id="billToEmail"
                  type="email"
                  {...form.register('billToEmail')}
                  placeholder="Enter email address"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="billToAddress">Address</Label>
                <Input
                  id="billToAddress"
                  {...form.register('billToAddress')}
                  placeholder="Enter address"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Gradient section divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-emerald-300 dark:via-emerald-700 to-transparent" />

        {/* SECTION 3 - Item Table */}
        <Card className="border-border/50 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <svg className="h-5 w-5 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="3" y="3" width="18" height="18" rx="2" />
                <path d="M3 9h18" />
                <path d="M3 15h18" />
                <path d="M9 3v18" />
              </svg>
              Items
            </CardTitle>
          </CardHeader>
          <CardContent>
            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-2 text-sm font-medium text-muted-foreground w-[40%]">Description</th>
                    <th className="text-center py-3 px-2 text-sm font-medium text-muted-foreground w-[12%]">Qty</th>
                    <th className="text-center py-3 px-2 text-sm font-medium text-muted-foreground w-[15%]">Rate</th>
                    <th className="text-center py-3 px-2 text-sm font-medium text-muted-foreground w-[15%]">Tax(%)</th>
                    <th className="text-right py-3 px-2 text-sm font-medium text-muted-foreground w-[15%]">Amount</th>
                    <th className="w-[3%]"></th>
                  </tr>
                </thead>
                <tbody>
                  {fields.map((field, index) => {
                    const item = watchedItems[index]
                    return (
                      <tr
                        key={field.id}
                        className="border-b border-border/50 hover:bg-muted/20 transition-colors"
                      >
                        <td className="py-2 px-2">
                          <Input
                            id={`item-desc-${index}`}
                            {...form.register(`items.${index}.description`)}
                            placeholder="Item description"
                            className="border-0 shadow-none focus-visible:ring-1 focus-visible:ring-emerald-500/50 px-1 h-9"
                            autoComplete="off"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <Input
                            id={`item-qty-${index}`}
                            type="number"
                            step="1"
                            min="0"
                            {...form.register(`items.${index}.quantity`, { valueAsNumber: true })}
                            className="text-center border-0 shadow-none focus-visible:ring-1 focus-visible:ring-emerald-500/50 px-1 h-9"
                            autoComplete="off"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <Input
                            id={`item-rate-${index}`}
                            type="number"
                            step="0.01"
                            min="0"
                            {...form.register(`items.${index}.rate`, { valueAsNumber: true })}
                            className="text-center border-0 shadow-none focus-visible:ring-1 focus-visible:ring-emerald-500/50 px-1 h-9"
                            autoComplete="off"
                          />
                        </td>
                        <td className="py-2 px-2">
                          <div className="flex items-center gap-1 justify-center">
                            <Select
                              value={
                                customTaxIndex === index
                                  ? '-1'
                                  : TAX_OPTIONS.find(t => t.value === item?.taxPercent)?.value?.toString() ?? '0'
                              }
                              onValueChange={(val) => handleTaxChange(index, val)}
                            >
                              <SelectTrigger className="w-20 h-8 text-xs">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {TAX_OPTIONS.map(option => (
                                  <SelectItem key={option.value} value={option.value.toString()}>
                                    {option.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            {customTaxIndex === index && (
                              <Input
                                type="number"
                                step="0.01"
                                min="0"
                                value={customTaxValues[index] ?? ''}
                                onChange={(e) => handleCustomTaxInput(index, e.target.value)}
                                className="w-16 h-8 text-xs text-center"
                                placeholder="%"
                                autoFocus
                              />
                            )}
                          </div>
                        </td>
                        <td className="py-2 px-2 text-right font-medium text-sm">
                          {(item?.amount ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-2 px-1">
                          {fields.length > 1 && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7 text-destructive hover:text-destructive"
                              onClick={() => remove(index)}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          )}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards */}
            <div className="md:hidden space-y-3">
              {fields.map((field, index) => {
                const item = watchedItems[index]
                return (
                  <div
                    key={field.id}
                    className="border border-border/50 rounded-lg p-3 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-muted-foreground">Item {index + 1}</span>
                      {fields.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive hover:text-destructive"
                          onClick={() => remove(index)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      )}
                    </div>
                    <Input
                      id={`mobile-item-desc-${index}`}
                      {...form.register(`items.${index}.description`)}
                      placeholder="Item description"
                      autoComplete="off"
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label className="text-xs">Quantity</Label>
                        <Input
                          id={`mobile-item-qty-${index}`}
                          type="number"
                          step="1"
                          min="0"
                          {...form.register(`items.${index}.quantity`, { valueAsNumber: true })}
                          autoComplete="off"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Rate</Label>
                        <Input
                          id={`mobile-item-rate-${index}`}
                          type="number"
                          step="0.01"
                          min="0"
                          {...form.register(`items.${index}.rate`, { valueAsNumber: true })}
                          autoComplete="off"
                        />
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1">
                        <Label className="text-xs">Tax</Label>
                        <Select
                          value={
                            customTaxIndex === index
                              ? '-1'
                              : TAX_OPTIONS.find(t => t.value === item?.taxPercent)?.value?.toString() ?? '0'
                          }
                          onValueChange={(val) => handleTaxChange(index, val)}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {TAX_OPTIONS.map(option => (
                              <SelectItem key={option.value} value={option.value.toString()}>
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      {customTaxIndex === index && (
                        <div className="w-20 mt-5">
                          <Input
                            type="number"
                            step="0.01"
                            min="0"
                            value={customTaxValues[index] ?? ''}
                            onChange={(e) => handleCustomTaxInput(index, e.target.value)}
                            placeholder="%"
                            autoFocus
                          />
                        </div>
                      )}
                    </div>
                    <div className="text-right font-medium">
                      Amount: {currencySymbol}{(item?.amount ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </div>
                  </div>
                )
              })}
            </div>

            <Button
              type="button"
              variant="outline"
              onClick={addItem}
              className="mt-4 w-full border-dashed border-emerald-300 text-emerald-600 hover:bg-emerald-50 hover:text-emerald-700 dark:hover:bg-emerald-950 dark:border-emerald-700 dark:text-emerald-400 bg-gradient-to-r from-emerald-50/50 to-teal-50/50 dark:from-emerald-950/30 dark:to-teal-950/30"
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Item
            </Button>
          </CardContent>
        </Card>

        {/* SECTION 4 - Totals */}
        <Card className="border-border/50 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <svg className="h-5 w-5 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="12" y1="1" x2="12" y2="23" />
                <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
              </svg>
              Totals
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-w-md ml-auto space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="font-medium">{currencySymbol}{subtotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Tax Total</span>
                <span className="font-medium">{currencySymbol}{taxTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
              </div>
              <Separator />
              <div className="flex justify-between text-lg font-bold">
                <span>Grand Total</span>
                <span className="text-emerald-600 dark:text-emerald-400">
                  {currencySymbol}{grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <Separator />
              <div className="flex justify-between items-center text-sm">
                <Label htmlFor="receivedAmount" className="text-muted-foreground cursor-pointer">Received Amount</Label>
                <Input
                  id="receivedAmount"
                  type="number"
                  step="0.01"
                  {...form.register('receivedAmount', { valueAsNumber: true })}
                  className="w-36 text-right h-8"
                />
              </div>
              <div className="flex justify-between items-center text-sm">
                <Label htmlFor="previousBalance" className="text-muted-foreground cursor-pointer">Previous Balance</Label>
                <Input
                  id="previousBalance"
                  type="number"
                  step="0.01"
                  {...form.register('previousBalance', { valueAsNumber: true })}
                  className="w-36 text-right h-8"
                />
              </div>
              <Separator />
              <div className="flex justify-between text-lg font-bold">
                <span>Current Balance</span>
                <span className={cn(
                  currentBalance > 0
                    ? 'text-amber-600 dark:text-amber-400'
                    : 'text-emerald-600 dark:text-emerald-400'
                )}>
                  {currencySymbol}{currentBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="bg-muted/50 rounded-md p-3 mt-2">
                <p className="text-xs text-muted-foreground mb-1">Amount in Words</p>
                <p className="text-sm font-medium">{amountInWords}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SECTION 5 - Terms */}
        <Card className="border-border/50 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <svg className="h-5 w-5 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                <polyline points="14 2 14 8 20 8" />
                <line x1="16" y1="13" x2="8" y2="13" />
                <line x1="16" y1="17" x2="8" y2="17" />
                <polyline points="10 9 9 9 8 9" />
              </svg>
              Terms & Conditions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              {...form.register('termsText')}
              placeholder="Enter terms and conditions..."
              rows={4}
              className="resize-none"
            />
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 justify-end pb-8">
          <Button
            type="button"
            variant="ghost"
            onClick={() => {
              setEditInvoiceId(null)
              setCurrentView('invoices')
            }}
            className="sm:order-1"
          >
            <X className="mr-2 h-4 w-4" />
            Cancel
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              setRecurringTemplateName('')
              setRecurringFrequency('monthly')
              setShowRecurringDialog(true)
            }}
            disabled={isSubmitting}
            className="sm:order-2 border-emerald-300 text-emerald-600 hover:bg-emerald-50 dark:border-emerald-700 dark:text-emerald-400 dark:hover:bg-emerald-950"
          >
            <RotateCcw className="mr-2 h-4 w-4" />
            Save as Recurring
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => onSubmit(form.getValues(), 'draft')}
            disabled={isSubmitting}
            className="sm:order-3"
          >
            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            Save as Draft
          </Button>
          <Button
            type="button"
            className="sm:order-4 bg-emerald-600 hover:bg-emerald-700 text-white"
            onClick={() => onSubmit(form.getValues(), 'sent')}
            disabled={isSubmitting}
          >
            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileText className="mr-2 h-4 w-4" />}
            Generate Invoice
          </Button>
        </div>
      </form>

      {/* Save as Recurring Dialog */}
      <Dialog open={showRecurringDialog} onOpenChange={setShowRecurringDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save as Recurring Invoice</DialogTitle>
            <DialogDescription>
              Save this invoice as a template to auto-generate on a schedule.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Template Name</Label>
              <Input
                value={recurringTemplateName}
                onChange={(e) => setRecurringTemplateName(e.target.value)}
                placeholder="e.g. Monthly Retainer for Acme Corp"
              />
            </div>
            <div className="space-y-2">
              <Label>Frequency</Label>
              <Select value={recurringFrequency} onValueChange={setRecurringFrequency}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="quarterly">Quarterly</SelectItem>
                  <SelectItem value="yearly">Yearly</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRecurringDialog(false)}>Cancel</Button>
            <Button
              onClick={async () => {
                if (!user?.id) return
                const values = form.getValues()
                try {
                  const res = await fetch('/api/invoices/recurring', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      userId: user.id,
                      templateName: recurringTemplateName || `Recurring - ${values.billToName || 'Invoice'}`,
                      frequency: recurringFrequency,
                      nextDate: values.invoiceDate,
                      billToName: values.billToName,
                      billToPhone: values.billToPhone,
                      billToEmail: values.billToEmail,
                      billToAddress: values.billToAddress,
                      currency: values.currency || 'INR',
                      items: values.items,
                      termsText: values.termsText,
                    }),
                  })
                  if (res.ok) {
                    toast.success('Recurring invoice template saved!')
                    setShowRecurringDialog(false)
                  } else {
                    toast.error('Failed to save recurring template')
                  }
                } catch {
                  toast.error('Failed to save recurring template')
                }
              }}
              className="bg-emerald-600 hover:bg-emerald-700 text-white"
            >
              Save Template
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Invoice Templates Dialog */}
      <InvoiceTemplates
        open={showTemplates}
        onOpenChange={setShowTemplates}
        currentTemplate={selectedTemplate}
        onTemplateChange={(template) => setSelectedTemplate(template)}
      />
    </motion.div>
  )
}
