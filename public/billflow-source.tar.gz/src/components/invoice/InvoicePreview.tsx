'use client'

import React, { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Download,
  Printer,
  Share2,
  ArrowLeft,
  Pencil,
  Loader2,
  Building2,
  Phone,
  Mail,
  MapPin,
  Send,
  Check,
} from 'lucide-react'
import { format } from 'date-fns'

import { cn } from '@/lib/utils'
import { useAppStore } from '@/stores/appStore'
import { getCurrencySymbol } from '@/lib/currency'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

interface InvoiceItem {
  id: string
  description: string
  quantity: number
  rate: number
  taxPercent: number
  amount: number
}

interface Invoice {
  id: string
  invoiceNumber: string
  invoiceDate: string
  dueDate: string
  status: string
  billToName: string
  billToPhone: string
  billToEmail: string
  billToAddress: string
  subtotal: number
  taxTotal: number
  grandTotal: number
  receivedAmount: number
  previousBalance: number
  currentBalance: number
  amountInWords: string
  termsText: string
  currency: string
  items: InvoiceItem[]
}

interface BusinessProfile {
  companyName: string
  companyAddress: string
  companyPhone: string
  companyEmail: string
  companyWebsite: string
  gstNumber: string
  panNumber: string
  companyLogo: string
  accountHolderName: string
  bankName: string
  accountNumber: string
  ifscCode: string
  branchName: string
  qrCode: string
  signatureImage: string
  sealImage: string
  sealCompanyName: string
  useSeal: boolean
}

export default function InvoicePreview() {
  const { user, previewInvoiceId, setCurrentView, setEditInvoiceId, setPreviewInvoiceId } = useAppStore()
  const [invoice, setInvoice] = useState<Invoice | null>(null)
  const [businessProfile, setBusinessProfile] = useState<BusinessProfile | null>(null)
  const [notFoundId, setNotFoundId] = useState<string | null>(null)
  const printRef = useRef<HTMLDivElement>(null)

  // Email share state
  const [showEmailDialog, setShowEmailDialog] = useState(false)
  const [shareEmail, setShareEmail] = useState('')
  const [shareMessage, setShareMessage] = useState('')
  const [shareLoading, setShareLoading] = useState(false)
  const [shareSuccess, setShareSuccess] = useState(false)

  // Derive states: notFound is specific to the current previewInvoiceId
  const notFound = notFoundId === previewInvoiceId
  const loading = !!previewInvoiceId && !!user?.id && invoice?.id !== previewInvoiceId && !notFound

  useEffect(() => {
    if (!user?.id || !previewInvoiceId) {
      if (!previewInvoiceId && user?.id) {
        fetch(`/api/profile?userId=${user.id}`)
          .then(r => r.json())
          .then(profileData => {
            if (profileData.businessProfile) {
              setBusinessProfile(profileData.businessProfile)
            }
          })
          .catch(() => {})
      }
      return
    }

    // Skip if we already have this invoice loaded
    if (invoice?.id === previewInvoiceId) return

    let cancelled = false

    Promise.all([
      fetch(`/api/invoices/detail?id=${previewInvoiceId}&userId=${user.id}`).then(r => {
        if (!r.ok) throw new Error('Invoice not found')
        return r.json()
      }),
      fetch(`/api/profile?userId=${user.id}`).then(r => r.json()),
    ])
      .then(([invoiceData, profileData]) => {
        if (cancelled) return
        if (invoiceData.invoice) {
          setInvoice(invoiceData.invoice)
          setNotFoundId(null)
        } else {
          setNotFoundId(previewInvoiceId)
        }
        if (profileData.businessProfile) {
          setBusinessProfile(profileData.businessProfile)
        }
      })
      .catch(() => {
        if (cancelled) return
        toast.error('Failed to load invoice data')
        setNotFoundId(previewInvoiceId)
      })

    return () => { cancelled = true }
  }, [user?.id, previewInvoiceId, invoice?.id])

  const handlePrint = () => {
    window.print()
  }

  const handleDownloadPDF = () => {
    window.print()
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Invoice ${invoice?.invoiceNumber}`,
          text: `Invoice ${invoice?.invoiceNumber} for ${invoice?.billToName}`,
        })
      } catch {
        // User cancelled share
      }
    } else {
      toast.info('Share not supported in this browser')
    }
  }

  const handleEdit = () => {
    if (invoice) {
      setEditInvoiceId(invoice.id)
      setPreviewInvoiceId(null)
      setCurrentView('create-invoice')
    }
  }

  const handleOpenEmailDialog = () => {
    if (invoice) {
      setShareEmail(invoice.billToEmail || '')
      setShareMessage('')
      setShareSuccess(false)
      setShowEmailDialog(true)
    }
  }

  const handleSendEmail = async () => {
    if (!invoice || !user?.id || !shareEmail.trim()) {
      toast.error('Please enter an email address')
      return
    }

    setShareLoading(true)
    try {
      const response = await fetch('/api/invoices/share', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          invoiceId: invoice.id,
          userId: user.id,
          email: shareEmail.trim(),
          message: shareMessage.trim() || undefined,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Failed to share invoice')
      }

      setShareSuccess(true)
      toast.success(`Invoice ${invoice.invoiceNumber} shared with ${shareEmail}`)
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to share invoice')
    } finally {
      setShareLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
      </div>
    )
  }

  if (!invoice) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <p className="text-muted-foreground">Invoice not found</p>
        <Button variant="outline" onClick={() => setCurrentView('invoices')}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Invoices
        </Button>
      </div>
    )
  }

  // Use business profile or sensible defaults for demo users without a profile
  const company: BusinessProfile = businessProfile || {
    companyName: user?.name || 'Your Company',
    companyAddress: '',
    companyPhone: user?.phone || '',
    companyEmail: user?.email || '',
    companyWebsite: '',
    gstNumber: '',
    panNumber: '',
    companyLogo: '/logo.png',
    accountHolderName: '',
    bankName: '',
    accountNumber: '',
    ifscCode: '',
    branchName: '',
    qrCode: '',
    signatureImage: '',
    sealImage: '',
    sealCompanyName: '',
    useSeal: false,
  }

  // Use the user's name as company name fallback if business profile doesn't have one
  const displayName = company.companyName || user?.name || 'Your Company'

  // Get currency symbol
  const cs = getCurrencySymbol(invoice.currency || 'INR')

  const statusColorMap: Record<string, string> = {
    draft: 'bg-gray-100 text-gray-700 border-gray-200',
    sent: 'bg-blue-50 text-blue-700 border-blue-200',
    paid: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    overdue: 'bg-red-50 text-red-700 border-red-200',
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="max-w-4xl mx-auto p-4 md:p-6 space-y-4 animate-fade-in"
    >
      {/* Action Buttons - hidden on print */}
      <div className="print:hidden flex flex-wrap items-center gap-2 justify-between">
        <Button
          variant="ghost"
          onClick={() => {
            setPreviewInvoiceId(null)
            setCurrentView('invoices')
          }}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Invoices
        </Button>
        <div className="flex flex-wrap gap-2">
          <Button variant="ghost" onClick={handleEdit}>
            <Pencil className="mr-2 h-4 w-4" />
            Edit
          </Button>
          <Button variant="outline" onClick={handleShare}>
            <Share2 className="mr-2 h-4 w-4" />
            Share
          </Button>
          <Button
            variant="outline"
            className="border-emerald-300 text-emerald-700 hover:bg-emerald-50 dark:border-emerald-700 dark:text-emerald-400 dark:hover:bg-emerald-950"
            onClick={handleOpenEmailDialog}
          >
            <Mail className="mr-2 h-4 w-4" />
            Share via Email
          </Button>
          <Button variant="outline" onClick={handlePrint}>
            <Printer className="mr-2 h-4 w-4" />
            Print
          </Button>
          <Button
            className="bg-emerald-600 hover:bg-emerald-700 text-white"
            onClick={handleDownloadPDF}
          >
            <Download className="mr-2 h-4 w-4" />
            Download PDF
          </Button>
        </div>
      </div>

      {/* Invoice Document - always white/light for printing */}
      <div
        ref={printRef}
        className="bg-white text-gray-900 rounded-lg shadow-lg overflow-hidden print:shadow-none print:rounded-none"
      >
        <div className="p-6 md:p-10 space-y-0">
          {/* TOP SECTION - Company Header */}
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-start gap-4">
              {/* Company Logo */}
              <div className="w-16 h-16 md:w-20 md:h-20 flex-shrink-0 rounded-lg overflow-hidden border border-gray-200 bg-gray-50">
                {company.companyLogo ? (
                  <img
                    src={company.companyLogo}
                    alt="Company Logo"
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-emerald-50">
                    <Building2 className="w-8 h-8 text-emerald-600" />
                  </div>
                )}
              </div>
              <div>
                <h1 className="text-xl md:text-2xl font-bold text-gray-900">
                  {displayName}
                </h1>
                {company.companyAddress && (
                  <p className="text-sm text-gray-600 mt-0.5 flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    {company.companyAddress}
                  </p>
                )}
                {company.companyPhone && (
                  <p className="text-sm text-gray-600 flex items-center gap-1">
                    <Phone className="w-3 h-3" />
                    {company.companyPhone}
                  </p>
                )}
                {company.companyEmail && (
                  <p className="text-sm text-gray-600 flex items-center gap-1">
                    <Mail className="w-3 h-3" />
                    {company.companyEmail}
                  </p>
                )}
                <div className="flex gap-4 mt-1">
                  {company.gstNumber && (
                    <span className="text-xs text-gray-500">GSTIN: {company.gstNumber}</span>
                  )}
                  {company.panNumber && (
                    <span className="text-xs text-gray-500">PAN: {company.panNumber}</span>
                  )}
                </div>
              </div>
            </div>

            {/* Badge */}
            <div className="flex flex-col items-end gap-2">
              <span className="bg-emerald-600 text-white text-xs font-semibold px-3 py-1 rounded-sm tracking-wide">
                ORIGINAL FOR RECIPIENT
              </span>
              <Badge
                className={cn(
                  'text-xs border',
                  statusColorMap[invoice.status] || 'bg-gray-100 text-gray-700 border-gray-200'
                )}
              >
                {invoice.status.toUpperCase()}
              </Badge>
            </div>
          </div>

          {/* INVOICE HEADER ROW */}
          <div className="bg-emerald-600 text-white rounded-t-md px-4 py-3 flex items-center justify-between">
            <div className="text-center flex-1">
              <p className="text-[10px] uppercase tracking-wider opacity-80">Invoice No.</p>
              <p className="font-bold text-sm">{invoice.invoiceNumber}</p>
            </div>
            <div className="w-px h-8 bg-emerald-500" />
            <div className="text-center flex-1">
              <p className="text-[10px] uppercase tracking-wider opacity-80">Invoice Date</p>
              <p className="font-bold text-sm">
                {invoice.invoiceDate ? format(new Date(invoice.invoiceDate), 'dd MMM yyyy') : '-'}
              </p>
            </div>
            <div className="w-px h-8 bg-emerald-500" />
            <div className="text-center flex-1">
              <p className="text-[10px] uppercase tracking-wider opacity-80">Due Date</p>
              <p className="font-bold text-sm">
                {invoice.dueDate ? format(new Date(invoice.dueDate), 'dd MMM yyyy') : '-'}
              </p>
            </div>
          </div>

          {/* BILL TO SECTION */}
          <div className="border border-t-0 border-gray-200 rounded-b-md p-4 bg-gray-50/50">
            <p className="text-xs uppercase tracking-wider text-gray-500 font-semibold mb-2">Bill To</p>
            <p className="font-bold text-gray-900">{invoice.billToName || '-'}</p>
            {invoice.billToAddress && (
              <p className="text-sm text-gray-600 mt-0.5">{invoice.billToAddress}</p>
            )}
            <div className="flex gap-4 mt-1">
              {invoice.billToPhone && (
                <p className="text-xs text-gray-500">Ph: {invoice.billToPhone}</p>
              )}
              {invoice.billToEmail && (
                <p className="text-xs text-gray-500">{invoice.billToEmail}</p>
              )}
            </div>
          </div>

          {/* ITEM TABLE */}
          <div className="mt-4 border border-gray-200 rounded-md overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-100 border-b border-gray-200">
                  <th className="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Items
                  </th>
                  <th className="text-center py-3 px-3 text-xs font-semibold text-gray-600 uppercase tracking-wider w-16">
                    Qty.
                  </th>
                  <th className="text-right py-3 px-3 text-xs font-semibold text-gray-600 uppercase tracking-wider w-24">
                    Rate
                  </th>
                  <th className="text-center py-3 px-3 text-xs font-semibold text-gray-600 uppercase tracking-wider w-16">
                    Tax(%)
                  </th>
                  <th className="text-right py-3 px-4 text-xs font-semibold text-gray-600 uppercase tracking-wider w-28">
                    Amount
                  </th>
                </tr>
              </thead>
              <tbody>
                {invoice.items?.map((item, index) => (
                  <tr
                    key={item.id || index}
                    className={cn(
                      'border-b border-gray-100',
                      index % 2 === 1 ? 'bg-gray-50/50' : 'bg-white'
                    )}
                  >
                    <td className="py-2.5 px-4 text-sm text-gray-800">{item.description || '-'}</td>
                    <td className="py-2.5 px-3 text-sm text-center text-gray-700">{item.quantity}</td>
                    <td className="py-2.5 px-3 text-sm text-right text-gray-700">
                      {cs}{item.rate.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-2.5 px-3 text-sm text-center text-gray-700">{item.taxPercent}%</td>
                    <td className="py-2.5 px-4 text-sm text-right font-medium text-gray-900">
                      {cs}{item.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))}
                {/* Fill empty rows for a professional look */}
                {invoice.items?.length > 0 && invoice.items.length < 5 && (
                  Array.from({ length: 5 - invoice.items.length }).map((_, i) => (
                    <tr key={`empty-${i}`} className={cn('border-b border-gray-100', (invoice.items.length + i) % 2 === 1 ? 'bg-gray-50/50' : 'bg-white')}>
                      <td className="py-2.5 px-4">&nbsp;</td>
                      <td className="py-2.5 px-3"></td>
                      <td className="py-2.5 px-3"></td>
                      <td className="py-2.5 px-3"></td>
                      <td className="py-2.5 px-4"></td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* TOTAL SECTION */}
          <div className="mt-2 flex justify-end">
            <div className="w-full md:w-72 space-y-1.5">
              <div className="flex justify-between py-1.5 px-4 text-sm">
                <span className="text-gray-500">Subtotal</span>
                <span className="font-medium text-gray-700">
                  {cs}{invoice.subtotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="flex justify-between py-1.5 px-4 text-sm">
                <span className="text-gray-500">Tax</span>
                <span className="font-medium text-gray-700">
                  {cs}{invoice.taxTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="bg-emerald-600 text-white rounded-md py-2.5 px-4 flex justify-between items-center">
                <span className="font-semibold">Grand Total</span>
                <span className="font-bold text-lg">
                  {cs}{invoice.grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="flex justify-between py-1.5 px-4 text-sm border-t border-gray-200 mt-2">
                <span className="text-gray-500">Received Amount</span>
                <span className="font-medium text-gray-700">
                  {cs}{invoice.receivedAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="flex justify-between py-1.5 px-4 text-sm">
                <span className="text-gray-500">Previous Balance</span>
                <span className="font-medium text-gray-700">
                  {cs}{invoice.previousBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="flex justify-between py-2 px-4 text-sm border-t border-gray-300 bg-amber-50 rounded-md">
                <span className="font-semibold text-amber-800">Current Balance</span>
                <span className="font-bold text-amber-700">
                  {cs}{invoice.currentBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
              </div>
            </div>
          </div>

          {/* AMOUNT IN WORDS */}
          <div className="mt-4 bg-gray-50 border border-gray-200 rounded-md p-3">
            <p className="text-xs uppercase tracking-wider text-gray-500 font-semibold mb-1">
              Amount in Words
            </p>
            <p className="text-sm font-medium text-gray-800 italic">
              {invoice.amountInWords || '-'}
            </p>
          </div>

          {/* BANK DETAILS */}
          {(company.accountNumber || company.bankName || company.ifscCode) && (
            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gray-50 border border-gray-200 rounded-md p-4">
                <p className="text-xs uppercase tracking-wider text-gray-500 font-semibold mb-3">
                  Bank Details
                </p>
                <div className="space-y-1.5 text-sm">
                  {company.accountHolderName && (
                    <div className="flex">
                      <span className="text-gray-500 w-32 flex-shrink-0">Account Name</span>
                      <span className="text-gray-800 font-medium">{company.accountHolderName}</span>
                    </div>
                  )}
                  {company.accountNumber && (
                    <div className="flex">
                      <span className="text-gray-500 w-32 flex-shrink-0">Account Number</span>
                      <span className="text-gray-800 font-mono font-medium">{company.accountNumber}</span>
                    </div>
                  )}
                  {company.ifscCode && (
                    <div className="flex">
                      <span className="text-gray-500 w-32 flex-shrink-0">IFSC Code</span>
                      <span className="text-gray-800 font-mono font-medium">{company.ifscCode}</span>
                    </div>
                  )}
                  {company.bankName && (
                    <div className="flex">
                      <span className="text-gray-500 w-32 flex-shrink-0">Bank Name</span>
                      <span className="text-gray-800 font-medium">{company.bankName}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* QR Code */}
              {company.qrCode && (
                <div className="flex items-center justify-center">
                  <div className="border border-gray-200 rounded-md p-3 bg-white">
                    <img
                      src={company.qrCode}
                      alt="Payment QR Code"
                      className="w-32 h-32 object-contain"
                    />
                    <p className="text-xs text-center text-gray-500 mt-1">Scan to Pay</p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TERMS & CONDITIONS */}
          {invoice.termsText && (
            <div className="mt-4">
              <p className="text-xs uppercase tracking-wider text-gray-500 font-semibold mb-2">
                Terms & Conditions
              </p>
              <div className="text-sm text-gray-700 space-y-1">
                {invoice.termsText.split('\n').filter(Boolean).map((line, index) => (
                  <p key={index} className="flex gap-2">
                    <span className="text-gray-400 flex-shrink-0">{index + 1}.</span>
                    <span>{line}</span>
                  </p>
                ))}
              </div>
            </div>
          )}

          {/* BOTTOM SECTION - Signature */}
          <div className="mt-8 flex items-end justify-between">
            {/* QR on left if bank section not shown */}
            {company.qrCode && !(company.accountNumber || company.bankName) && (
              <div className="border border-gray-200 rounded-md p-2 bg-white">
                <img
                  src={company.qrCode}
                  alt="Payment QR Code"
                  className="w-24 h-24 object-contain"
                />
              </div>
            )}

            {/* Signature on right */}
            <div className="ml-auto text-center">
              {company.signatureImage ? (
                <div className="mb-2">
                  <img
                    src={company.signatureImage}
                    alt="Signature"
                    className="h-16 mx-auto object-contain"
                  />
                </div>
              ) : (
                <div className="border-b-2 border-gray-300 w-48 mb-2 h-16 flex items-end justify-center">
                  <span className="text-xs text-gray-400 mb-1">Sign Here</span>
                </div>
              )}
              <div className="border-t border-gray-400 w-48 pt-1">
                <p className="text-xs font-semibold text-gray-700">
                  AUTHORIZED SIGNATORY FOR {displayName?.toUpperCase() || 'COMPANY'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Email Share Dialog */}
      <Dialog open={showEmailDialog} onOpenChange={setShowEmailDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
                <Mail className="h-4 w-4 text-white" />
              </div>
              Share Invoice via Email
            </DialogTitle>
            <DialogDescription>
              Send invoice {invoice?.invoiceNumber} to your client via email. AI will generate a professional email body.
            </DialogDescription>
          </DialogHeader>

          <AnimatePresence mode="wait">
            {shareSuccess ? (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="py-8 flex flex-col items-center gap-3"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', stiffness: 200, damping: 15, delay: 0.1 }}
                  className="h-16 w-16 rounded-full bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center"
                >
                  <Check className="h-8 w-8 text-emerald-600" />
                </motion.div>
                <h3 className="text-lg font-semibold text-foreground">Invoice Shared!</h3>
                <p className="text-sm text-muted-foreground text-center">
                  Invoice {invoice?.invoiceNumber} has been shared with <span className="font-medium text-emerald-600">{shareEmail}</span>
                </p>
                <Button
                  className="mt-2 bg-emerald-600 hover:bg-emerald-700 text-white"
                  onClick={() => setShowEmailDialog(false)}
                >
                  Done
                </Button>
              </motion.div>
            ) : (
              <motion.div
                key="form"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <Label htmlFor="share-email">Recipient Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="share-email"
                      type="email"
                      value={shareEmail}
                      onChange={(e) => setShareEmail(e.target.value)}
                      placeholder="client@example.com"
                      className="pl-10 border-emerald-200 dark:border-emerald-800 focus-visible:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="share-message">
                    Personal Message <span className="text-muted-foreground text-xs">(optional)</span>
                  </Label>
                  <Textarea
                    id="share-message"
                    value={shareMessage}
                    onChange={(e) => setShareMessage(e.target.value)}
                    placeholder="Add a personal note to accompany the invoice..."
                    rows={3}
                    className="resize-none border-emerald-200 dark:border-emerald-800 focus-visible:ring-emerald-500"
                  />
                </div>

                {/* Invoice summary card */}
                <div className="rounded-lg border border-emerald-200 dark:border-emerald-800 bg-gradient-to-br from-emerald-50/80 to-teal-50/80 dark:from-emerald-950/30 dark:to-teal-950/30 p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground">Invoice</p>
                      <p className="font-semibold text-sm">{invoice?.invoiceNumber}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">Amount</p>
                      <p className="font-bold text-sm text-emerald-700 dark:text-emerald-400">
                        {cs}{invoice?.grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </p>
                    </div>
                  </div>
                </div>

                <DialogFooter className="gap-2 sm:gap-0">
                  <Button
                    variant="outline"
                    onClick={() => setShowEmailDialog(false)}
                    disabled={shareLoading}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleSendEmail}
                    disabled={shareLoading || !shareEmail.trim()}
                    className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white"
                  >
                    {shareLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="mr-2 h-4 w-4" />
                        Send Invoice
                      </>
                    )}
                  </Button>
                </DialogFooter>
              </motion.div>
            )}
          </AnimatePresence>
        </DialogContent>
      </Dialog>
    </motion.div>
  )
}
