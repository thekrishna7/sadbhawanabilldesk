'use client'

import React, { useEffect } from 'react'
import { useAppStore } from '@/stores/appStore'
import { AnimatePresence, motion } from 'framer-motion'
import dynamic from 'next/dynamic'
import { useKeyboardShortcuts } from '@/hooks/useKeyboardShortcuts'

// Layout
import DashboardLayout from '@/components/layout/DashboardLayout'
import GlobalSearch from '@/components/layout/GlobalSearch'

// Dashboard views
import DashboardHome from '@/components/dashboard/DashboardHome'
import ReportsPage from '@/components/dashboard/ReportsPage'
import RecycleBinPage from '@/components/dashboard/RecycleBinPage'
import NotificationCenter from '@/components/dashboard/NotificationCenter'

// Invoice views
import InvoiceForm from '@/components/invoice/InvoiceForm'
import InvoicePreview from '@/components/invoice/InvoicePreview'
import InvoiceList from '@/components/invoice/InvoiceList'
import CustomersPage from '@/components/invoice/CustomersPage'
import RecurringInvoicesPage from '@/components/invoice/RecurringInvoicesPage'

// Profile & Settings
import ProfilePage from '@/components/profile/ProfilePage'
import SettingsPage from '@/components/settings/SettingsPage'

// Landing & Auth - dynamic imports for performance
const LandingPage = dynamic(() => import('@/components/landing/LandingPage'), { ssr: false })
const LoginPage = dynamic(() => import('@/components/auth/LoginPage'), { ssr: false })
const SignupPage = dynamic(() => import('@/components/auth/SignupPage'), { ssr: false })
const ForgotPasswordPage = dynamic(() => import('@/components/auth/ForgotPasswordPage'), { ssr: false })

function DashboardRouter() {
  const { currentView } = useAppStore()

  // Enable keyboard shortcuts
  useKeyboardShortcuts()

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <DashboardHome />
      case 'invoices':
        return <InvoiceList />
      case 'create-invoice':
        return <InvoiceForm />
      case 'preview-invoice':
        return <InvoicePreview />
      case 'customers':
        return <CustomersPage />
      case 'recurring':
        return <RecurringInvoicesPage />
      case 'reports':
        return <ReportsPage />
      case 'profile':
        return <ProfilePage />
      case 'settings':
        return <SettingsPage />
      case 'recycle-bin':
        return <RecycleBinPage />
      case 'notifications':
        return <NotificationCenter />
      default:
        return <DashboardHome />
    }
  }

  return (
    <DashboardLayout>
      <GlobalSearch />
      <AnimatePresence mode="wait">
        <motion.div
          key={currentView}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.2, ease: 'easeInOut' }}
        >
          {renderView()}
        </motion.div>
      </AnimatePresence>
    </DashboardLayout>
  )
}

function SplashScreen() {
  const { setShowSplash } = useAppStore()

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 2500)
    return () => clearTimeout(timer)
  }, [setShowSplash])

  return (
    <motion.div
      className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-emerald-600 via-emerald-500 to-teal-500 text-white"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={() => setShowSplash(false)}
    >
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className="flex flex-col items-center gap-4"
      >
        <div className="size-20 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center shadow-2xl">
          <img src="/logo.png" alt="BillFlow" className="size-14 object-contain" />
        </div>
        <h1 className="text-4xl font-bold tracking-tight">BillFlow</h1>
        <p className="text-emerald-100 text-sm font-medium">Smart Billing Made Simple</p>
      </motion.div>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.5 }}
        className="mt-12"
      >
        <div className="flex gap-1.5">
          <motion.div
            className="size-2 rounded-full bg-white/80"
            animate={{ y: [0, -8, 0] }}
            transition={{ duration: 0.6, repeat: Infinity, delay: 0 }}
          />
          <motion.div
            className="size-2 rounded-full bg-white/80"
            animate={{ y: [0, -8, 0] }}
            transition={{ duration: 0.6, repeat: Infinity, delay: 0.15 }}
          />
          <motion.div
            className="size-2 rounded-full bg-white/80"
            animate={{ y: [0, -8, 0] }}
            transition={{ duration: 0.6, repeat: Infinity, delay: 0.3 }}
          />
        </div>
      </motion.div>
    </motion.div>
  )
}

function AuthRouter() {
  const { currentView } = useAppStore()

  switch (currentView) {
    case 'login':
      return <LoginPage />
    case 'signup':
      return <SignupPage />
    case 'forgot-password':
      return <ForgotPasswordPage />
    default:
      return <LandingPage />
  }
}

export default function Home() {
  const { isAuthenticated, showSplash } = useAppStore()

  if (showSplash) {
    return <SplashScreen />
  }

  if (!isAuthenticated) {
    return <AuthRouter />
  }

  return <DashboardRouter />
}
