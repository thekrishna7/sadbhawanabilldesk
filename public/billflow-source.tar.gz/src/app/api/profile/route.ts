import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json({ error: 'userId is required' }, { status: 400 })
    }

    const user = await db.user.findUnique({ where: { id: userId } })
    const businessProfile = await db.businessProfile.findUnique({ where: { userId } })

    return NextResponse.json({ user, businessProfile })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch profile' }, { status: 500 })
  }
}

export async function PUT(req: NextRequest) {
  try {
    const data = await req.json()
    const { userId, ...updateData } = data

    if (!userId) {
      return NextResponse.json({ error: 'userId is required' }, { status: 400 })
    }

    // Update user
    if (updateData.name !== undefined || updateData.phone !== undefined || updateData.email !== undefined || updateData.profilePhoto !== undefined) {
      await db.user.update({
        where: { id: userId },
        data: {
          ...(updateData.name !== undefined && { name: updateData.name }),
          ...(updateData.phone !== undefined && { phone: updateData.phone }),
          ...(updateData.email !== undefined && { email: updateData.email }),
          ...(updateData.profilePhoto !== undefined && { profilePhoto: updateData.profilePhoto }),
        }
      })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update profile' }, { status: 500 })
  }
}
