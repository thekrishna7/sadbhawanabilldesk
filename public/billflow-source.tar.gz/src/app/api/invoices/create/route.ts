import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(req: NextRequest) {
  try {
    const data = await req.json()
    const { userId, items, ...invoiceData } = data

    if (!userId) {
      return NextResponse.json({ error: 'userId is required' }, { status: 400 })
    }

    // Generate a unique invoice number
    let invoiceNumber = invoiceData.invoiceNumber
    
    if (!invoiceNumber) {
      const year = new Date().getFullYear()
      const existingCount = await db.invoice.count({
        where: { userId, invoiceNumber: { contains: `INV-${year}` } }
      })
      // Try the expected number first, then increment if collision
      let candidateNum = existingCount + 1
      let candidate = `INV-${year}-${String(candidateNum).padStart(3, '0')}`
      
      // Check for uniqueness (handle race conditions)
      for (let attempt = 0; attempt < 10; attempt++) {
        const existing = await db.invoice.findUnique({ where: { invoiceNumber: candidate } })
        if (!existing) break
        candidateNum++
        candidate = `INV-${year}-${String(candidateNum).padStart(3, '0')}`
      }
      invoiceNumber = candidate
    } else {
      // Verify the provided invoice number is unique
      const existing = await db.invoice.findUnique({ where: { invoiceNumber } })
      if (existing) {
        const year = new Date().getFullYear()
        const existingCount = await db.invoice.count({
          where: { userId, invoiceNumber: { contains: `INV-${year}` } }
        })
        invoiceNumber = `INV-${year}-${String(existingCount + 1).padStart(3, '0')}`
      }
    }

    // Ensure currency field is set
    const currency = invoiceData.currency || 'INR'

    const invoice = await db.invoice.create({
      data: {
        ...invoiceData,
        userId,
        invoiceNumber,
        currency,
        items: {
          create: items || []
        }
      },
      include: { items: true }
    })

    // Auto-save customer if name provided
    if (invoiceData.billToName && invoiceData.billToEmail) {
      const existingCustomer = await db.customer.findFirst({
        where: { userId, email: invoiceData.billToEmail }
      })
      if (!existingCustomer) {
        await db.customer.create({
          data: {
            userId,
            name: invoiceData.billToName,
            phone: invoiceData.billToPhone || '',
            email: invoiceData.billToEmail || '',
            address: invoiceData.billToAddress || '',
          }
        })
      }
    }

    return NextResponse.json({ invoice })
  } catch (error) {
    console.error('Invoice creation error:', error)
    return NextResponse.json({ error: 'Failed to create invoice' }, { status: 500 })
  }
}
