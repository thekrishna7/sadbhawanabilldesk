import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function PUT(req: NextRequest) {
  try {
    const data = await req.json()
    const { id, items, ...invoiceData } = data

    if (!id) {
      return NextResponse.json({ error: 'Invoice ID is required' }, { status: 400 })
    }

    // Delete existing items and recreate
    if (items) {
      await db.invoiceItem.deleteMany({ where: { invoiceId: id } })
    }

    const invoice = await db.invoice.update({
      where: { id },
      data: {
        ...invoiceData,
        items: items ? {
          create: items
        } : undefined
      },
      include: { items: true }
    })

    return NextResponse.json({ invoice })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update invoice' }, { status: 500 })
  }
}
