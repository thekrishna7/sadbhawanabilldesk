import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { db } from '@/lib/db'
import { logActivity } from '@/lib/activityLogger'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { invoiceId, userId, email, message } = body

    // Validate required fields
    if (!invoiceId || !userId || !email) {
      return NextResponse.json(
        { error: 'Missing required fields: invoiceId, userId, email' },
        { status: 400 }
      )
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Invalid email address format' },
        { status: 400 }
      )
    }

    // Fetch the invoice
    const invoice = await db.invoice.findUnique({
      where: { id: invoiceId },
      include: { items: true },
    })

    if (!invoice) {
      return NextResponse.json(
        { error: 'Invoice not found' },
        { status: 404 }
      )
    }

    // Verify ownership
    if (invoice.userId !== userId) {
      return NextResponse.json(
        { error: 'You do not have permission to share this invoice' },
        { status: 403 }
      )
    }

    // Fetch business profile for company name
    const businessProfile = await db.businessProfile.findUnique({
      where: { userId },
    })

    const companyName = businessProfile?.companyName || 'BillFlow User'
    const currencySymbol = invoice.currency === 'INR' ? '₹' : invoice.currency === 'USD' ? '$' : invoice.currency === 'EUR' ? '€' : '₹'

    // Use AI to generate a professional email body
    let emailBody: string
    try {
      const zai = await ZAI.create()

      const emailPrompt = `Generate a professional invoice email body with these details:
- Company: ${companyName}
- Invoice Number: ${invoice.invoiceNumber}
- Customer: ${invoice.billToName || 'Valued Customer'}
- Amount: ${currencySymbol}${invoice.grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
- Due Date: ${invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' }) : 'N/A'}
- Items: ${invoice.items.map(i => i.description).filter(Boolean).join(', ') || 'Various items'}
${message ? `- Personal message from sender: ${message}` : ''}

Write a warm, professional email that:
1. Has a clear subject line (prefixed with "SUBJECT:")
2. Greets the customer by name
3. Mentions the invoice number, amount, and due date
4. Briefly lists the items/services
5. Includes a call to action for payment
6. Has a professional closing with company name
Keep it concise (under 200 words). Do not include any markdown formatting.`

      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are a professional business email writer. Generate clear, concise, and professional invoice emails. Always start with "SUBJECT:" on the first line followed by the subject, then a blank line, then the email body.',
          },
          { role: 'user', content: emailPrompt },
        ],
        thinking: { type: 'disabled' },
      })

      emailBody = completion.choices?.[0]?.message?.content || ''
    } catch {
      // Fallback email body if AI fails
      emailBody = `SUBJECT: Invoice ${invoice.invoiceNumber} from ${companyName}

Dear ${invoice.billToName || 'Valued Customer'},

We hope this message finds you well. Please find below the details of invoice ${invoice.invoiceNumber}.

Invoice Amount: ${currencySymbol}${invoice.grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
Due Date: ${invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString('en-IN') : 'N/A'}

${message ? `Personal note: ${message}\n\n` : ''}Please process the payment at your earliest convenience. If you have any questions regarding this invoice, please don't hesitate to reach out.

Thank you for your business!

Best regards,
${companyName}`
    }

    // Log the share activity
    await logActivity({
      userId,
      action: 'shared',
      entityType: 'invoice',
      entityId: invoiceId,
      description: `Shared invoice ${invoice.invoiceNumber} via email to ${email}`,
      metadata: {
        invoiceNumber: invoice.invoiceNumber,
        sharedWithEmail: email,
        grandTotal: invoice.grandTotal,
        currency: invoice.currency,
        hasCustomMessage: !!message,
        emailBodyPreview: emailBody.slice(0, 100),
      },
    })

    // Return success with the generated email body
    return NextResponse.json({
      success: true,
      email,
      emailBody,
      invoiceNumber: invoice.invoiceNumber,
      companyName,
    })
  } catch (error) {
    console.error('Invoice share error:', error)
    return NextResponse.json(
      { error: 'Failed to share invoice. Please try again.' },
      { status: 500 }
    )
  }
}
